#ifndef __H_CLASS_H
#define __H_CLASS_H
#include "sys.h"

extern float yaw_angle_err;
extern float pitch_angle_err;
extern int yawcnt;
extern float imu_yaw1;
extern float imu_last1;

void Twist(void);//Ť��ģʽ
void Chassis_follow_Gimbal(float Vx, float Vy, float Wz, float pitch_angle,float Gimbal_Wz);//���̸�����̨����ģʽ
void Vision_Gimbal(float Vx,float Vy,float Chassis_Wz,float pitch_angle,float Gimbal_Wz);
void Vision_Gimbal_Reset(void);//���鸴λ

void powerLimitHandle(void);
void Power_off_function(void);
void Chassis_compensation (float Wz);
void chassis_set_contorl(void);
void gimbal_set_contorl(void);

void Astrict_Acc(float Vx,float Vy,float Wz);
#endif

