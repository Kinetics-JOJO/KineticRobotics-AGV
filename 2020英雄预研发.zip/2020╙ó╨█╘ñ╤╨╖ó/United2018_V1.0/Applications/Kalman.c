#include "Kalman.h"

kalman1 Vision_kalman_x;
kalman1 Vision_kalman_y;

void kalmanCreate(void)
{
	Vision_kalman_y.Q1 = 0.1;
	Vision_kalman_y.R1 = 0.1;
	Vision_kalman_y.P_last1 = 1;
	Vision_kalman_y.A1 = 1;
	Vision_kalman_y.X_last1 = 0;
	Vision_kalman_y.X_last_last1 = 0;
	Vision_kalman_y.H1 = 1;
	
	Vision_kalman_x.Q1 = 0.1;
	Vision_kalman_x.R1 = 0.1;
	Vision_kalman_x.P_last1 = 1;
	Vision_kalman_x.A1 = 1;
	Vision_kalman_x.X_last1 = 0;
	Vision_kalman_x.X_last_last1 = 0;
	Vision_kalman_x.H1 = 1;
}

float KalmanFilter(kalman1 *p,float dat)
{
    p->X_mid1 =p->A1*p->X_last1;                     
    p->P_mid1 = p->A1*p->P_last1+p->Q1;               
    p->K1 = p->P_mid1/(p->P_mid1+p->R1);             
    p->X_now1 = p->X_mid1+p->K1*(dat-p->X_mid1);     
    p->P_last1 = (1-p->K1)*p->P_mid1;
   	p->X_last_last1 = p->X_last1;  
    p->X_last1 = p->X_now1;
	  return p->X_now1;
}

void Kalman_Reset(kalman1 *p)
{
	p->P_last1 = 1;
	p->X_last1 = 0;
	p->X_last_last1 = 0;
}



