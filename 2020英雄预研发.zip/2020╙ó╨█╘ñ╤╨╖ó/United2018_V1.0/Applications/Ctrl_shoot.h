#ifndef SHOOT_H
#define SHOOT_H
#include "sys.h"
#include "can1.h"

extern int shoot_ready_flag;
extern  int Block_42_flag ;
extern  int Block_42cnt  ;
extern 	int contine_shoot_time1 ;
extern int block_flag;
extern int single_flag;
extern int16_t trigger_moto_speed_ref2;
static void Encoder_Data_Handle( M_Data*ptr);
static void Fire_PID_Init(void);
void shoot_task(void);
void FRT_shoot_task(void *pvParameters);
void block_bullet_handle(void);
void shoot_task1(void);
void shoot_ready_control(void);

#endif
