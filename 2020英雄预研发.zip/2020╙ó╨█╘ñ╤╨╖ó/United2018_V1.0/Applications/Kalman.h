#ifndef __KALMAN_H
#define __KALMAN_H
#include "stdint.h"
#include "sys.h"
#include "Configuration.h"

typedef struct Kalman_data
{
	float Q1;
	float R1;
	float P_last1;
	float A1;
	float X_last1;
	float X_last_last1;
	float H1;
	float X_mid1;
	float P_mid1;
	float K1;
	float X_now1;
}kalman1;

extern kalman1 Vision_kalman_x;
extern kalman1 Vision_kalman_y;


void kalmanCreate(void);
float KalmanFilter(kalman1 *p,float dat);
void Kalman_Reset(kalman1 *p);












#endif
