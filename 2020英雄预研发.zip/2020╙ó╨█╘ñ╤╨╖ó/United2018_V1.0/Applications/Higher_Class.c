///*************************************************************************
// *�߼�����ʵ��
// *���ƹ���
// *Ť��ģʽ
// *��̨����ģʽ
// *�Ӿ��Զ���׼ģʽ
// *
// *************************************************************************/
#include "Higher_Class.h"
#include "User_Api.h"
#include "Ctrl_gimbal.h"
#include "IMU.h"
#include "MPU6500.h"
#include "Configuration.h"
#include "led.h"
#include "buzzer.h"
#include "RemoteControl.h"
#include "can1.h"
#include "can2.h"
#include "Ctrl_chassis.h"
#include "Comm_umpire.h"
#include <math.h>
#include <stdlib.h>
#include "PID.h"
#include "Kalman.h"
#include "Ctrl_shoot.h"
#include "pwm.h"
#include "laser.h"
float imu_yaw1 = 0;//���ڵ����˶�����
int yawcnt = 0;//���ڵ����˶�����

float imu_last1;//������ת180�ȵı���

float Twist_buff;

float yaw_angle_err = 0;
float pitch_angle_err = 0;
float yaw_angle_err_last = 0;
float pitch_angle_err_last = 0;

static float Vx_Lpf=0,Vy_Lpf=0,Wz_Lpf=0;	//���Ƽ��ٶȺ���˶���
int16_t ACC_Offset = 0;//���ٶ�ƫ�ã����ڹ��ʿ���

void chassis_set_contorl(void)//���̿���������
{
	if(Twist_Flag)//Ť��
  {
	Encoder_angle_Handle();//���̽Ƕ�ת��
	if(Yaw_Encode_Angle>=10)	//��̨�ڵ����ұ�
	{
		Twist_buff = -TWIST_SPEED;
	}
	else if(Yaw_Encode_Angle<=-10)	//��̨�ڵ������
	{
		Twist_buff = TWIST_SPEED;
	}
	Control_data.Chassis_Wz = Twist_buff;
	}
	
  else if(Gimbal_180_flag)//һ��180
	Control_data.Chassis_Wz = PI + (-Yaw_Encode_Angle)*1.5f;
	
	
	else
	{
	if(Chassismode_flag)//������̨������ģʽ���̲���
	{
	if(imu.yaw > 170 | imu.yaw <-170)
	{ 
		yawcnt = 0;
		return;
	}
		if(!(RC_Ctl.rc.ch2-1024) && !RC_Ctl.mouse.x)	
	{
		if(!yawcnt)
		{
			imu_yaw1 =  imu.yaw;
			yawcnt++;
		}		
			Control_data.Chassis_Wz = Control_data.Chassis_Wz*0.2f + ( imu.yaw - imu_yaw1)*0.1f;
	}
	else
	yawcnt = 0;
	
	}		
	
	else
	{
		if(RC_Ctl.rc.s2 == RC_SW_MID)//ң����ģʽ���̿�������
		{
			Control_data.Chassis_Wz = Control_data.Chassis_Wz*0.2f + (-Yaw_Encode_Angle) * 0.1f;
		}
	  if(RC_Ctl.rc.s2 == RC_SW_UP)//����ģʽ���̿�������
		{
	    Control_data.Chassis_Wz = Control_data.Chassis_Wz*0.1f + (-Yaw_Encode_Angle) * 0.1f;
   }
	}
  }
	
	if (Control_data.Chassis_Wz > Wz_MAX)	Control_data.Chassis_Wz = Wz_MAX;
  else if (Control_data.Chassis_Wz < -Wz_MAX) Control_data.Chassis_Wz = -Wz_MAX;
} 


#define CAM_FOV 38.0f	//����ͷ�Ƕ�
void gimbal_set_contorl(void)
{
	if(Vision_Flag)
	{
	if (!Vision_Data.target_lose)//ʶ��
	{
		yaw_angle_err_last = yaw_angle_err;
		yaw_angle_err = (Vision_Data.x - VISION_X_Offset) * (CAM_FOV/(float)VISION_X_Pixels)+ (Vision_Data.x_last - Vision_Data.x_last_last)*0.11f;
		if(fabs(yaw_angle_err - yaw_angle_err_last) < 2.8f)
			yaw_angle_err = 0;
		yaw_angle_err = KalmanFilter(&Vision_kalman_x,yaw_angle_err);
		if (yaw_angle_err>Vision_SPEED_X) yaw_angle_err = Vision_SPEED_X;
		else if (yaw_angle_err<-Vision_SPEED_X) yaw_angle_err = -Vision_SPEED_X;
	}  
  else //ûʶ��
	{
	yaw_angle_err = 0;
	Kalman_Reset(&Vision_kalman_x);	
	}
	
	
	if (!Vision_Data.target_lose)//ʶ��
	{ 
		pitch_angle_err_last = pitch_angle_err;
		pitch_angle_err =  (Vision_Data.y - VISION_Y_Offset) * (CAM_FOV/(float)VISION_X_Pixels) +  (Vision_Data.y_last - Vision_Data.y_last_last)*0.1f;
		if(fabs(pitch_angle_err - 	pitch_angle_err_last) < 2.5f)
		pitch_angle_err = 0;
		pitch_angle_err = KalmanFilter(&Vision_kalman_y,pitch_angle_err);
		if (pitch_angle_err>Vision_SPEED_Y) pitch_angle_err = Vision_SPEED_Y;
		else if (pitch_angle_err<-Vision_SPEED_Y) pitch_angle_err = -Vision_SPEED_Y;
	}
	
	else //ûʶ��
	{
	pitch_angle_err = 0;
  Kalman_Reset(&Vision_kalman_y);				
	}
	
	Control_data.Gimbal_Wz = 0.015*RC_Ctl.mouse.x + yaw_angle_err;
	Control_data.Pitch_angle += pitch_angle_err;
	}
	
	
	if(Gimbal_180_flag)
	Control_data.Gimbal_Wz = 0.25f;
	

	else//���̸�����̨
	{
		if(RC_Ctl.rc.s2 == RC_SW_MID)//ң����ģʽ��̨��������
		{
		if((15 < Yaw_Encode_Angle && Control_data.Gimbal_Wz < 0)| (Yaw_Encode_Angle < -15 && Control_data.Gimbal_Wz >0))
		Control_data.Gimbal_Wz = Control_data.Gimbal_Wz*0.1f;
		else 
		Control_data.Gimbal_Wz = Control_data.Gimbal_Wz*2;	
		}
		if(RC_Ctl.rc.s2 == RC_SW_UP)//����ģʽ��̨��������
		{
		if( (15 < Yaw_Encode_Angle && Control_data.Gimbal_Wz < 0)| (Yaw_Encode_Angle < -15 && Control_data.Gimbal_Wz >0))
		Control_data.Gimbal_Wz = Control_data.Gimbal_Wz*0.1f;
		else 
		Control_data.Gimbal_Wz = Control_data.Gimbal_Wz*2;
    }
	}
	if(Control_data.Gimbal_Wz > 0.5f)//��̨�������޷�
		Control_data.Gimbal_Wz = 0.5f;
	if(Control_data.Gimbal_Wz < -0.5f)
		Control_data.Gimbal_Wz = -0.5f;
}


//����û�кõĳ������ݷ�����ͨ�����Ƽ��ٶ�����ֹ�������Լ����ٳ������ݵ�������
//���Ƽ��ٶ�
//���ƺ���ֵ������Vx_Lpf,Vy_Lpf,Wz_Lpf��
#define LOW_SPEED	800	//��������
static float Acc_x = X_ACC_MAX/PID_Hz,Acc_y = Y_ACC_MAX/PID_Hz,Acc_z = 1;//�����ٶ�
void Astrict_Acc(float Vx,float Vy,float Wz)
{
	if((Vx_Lpf>LOW_SPEED)||(Vx_Lpf<-LOW_SPEED))
	{
		if((Vx-Vx_Lpf) > (Acc_x+ACC_Offset))	Vx_Lpf += (Acc_x+ACC_Offset);
		else if((Vx-Vx_Lpf) < -(Acc_x+ACC_Offset))	Vx_Lpf -= (Acc_x+ACC_Offset);
		else Vx_Lpf = Vx;
	}
	else
	{
		//�����ٶȸı���ٶȴ�С����Ϊ������ɲ�������״�
		float k = 0.6 + 0.4*fabs(Vx_Lpf)/LOW_SPEED;
		k *= Acc_x;
		if((Vx-Vx_Lpf)>k)	Vx_Lpf += k;
		else if((Vx-Vx_Lpf)<-k)	Vx_Lpf -= k;
		else Vx_Lpf = Vx;
	}
	if((Vy_Lpf>LOW_SPEED)||(Vy_Lpf<-LOW_SPEED))
	{
		if( (Vy-Vy_Lpf) > (Acc_y+ACC_Offset) )	Vy_Lpf += (Acc_y+ACC_Offset);
		else if((Vy-Vy_Lpf) < -(Acc_y+ACC_Offset))	Vy_Lpf -= (Acc_y+ACC_Offset);
		else Vy_Lpf = Vy;
	}
	else
	{
		float k = 0.6 + 0.4*fabs(Vy_Lpf)/LOW_SPEED;
		k *= Acc_y;
		if((Vy-Vy_Lpf)>k)	Vy_Lpf += k;
		else if((Vy-Vy_Lpf)<-k)	Vy_Lpf -= k;
		else Vy_Lpf = Vy;
	}
	if((Wz-Wz_Lpf) > Acc_z)	Wz_Lpf += Acc_z;
	else if((Wz-Wz_Lpf) < -Acc_z)	Wz_Lpf -= Acc_z;
	else Wz_Lpf = Wz;
	
	Control_data.Vx = Vx_Lpf;
	Control_data.Vy = Vy_Lpf;
	Control_data.Chassis_Wz = Wz_Lpf;
}


void powerLimitHandle(void)//��������
{
	if(offline_flag >= 2000)
	{
		return;
	}
	float totalCurrentrTemp;
	if(Umpire_PowerHeat.chassis_power_buffer - (Umpire_PowerHeat.chassis_power)*0.26f < 7.0f)
	{
		totalCurrentrTemp = fabs(motor_speed_pid[0].Control_OutPut)
												+ fabs(motor_speed_pid[1].Control_OutPut)
												+ fabs(motor_speed_pid[2].Control_OutPut)
												+ fabs(motor_speed_pid[3].Control_OutPut);
		motor_speed_pid[0].Control_OutPut = (motor_speed_pid[0].Control_OutPut/(totalCurrentrTemp+1))*3000.0f
																						*(0.1f + Umpire_PowerHeat.chassis_power_buffer * 0.15f);
		motor_speed_pid[1].Control_OutPut = (motor_speed_pid[1].Control_OutPut/(totalCurrentrTemp+1))*3000.0f
																						*(0.1f + Umpire_PowerHeat.chassis_power_buffer * 0.15f);
		motor_speed_pid[2].Control_OutPut = (motor_speed_pid[2].Control_OutPut/(totalCurrentrTemp+1))*3000.0f
																						*(0.1f + Umpire_PowerHeat.chassis_power_buffer * 0.15f);
		motor_speed_pid[3].Control_OutPut = (motor_speed_pid[3].Control_OutPut/(totalCurrentrTemp+1))*3000.0f
																						*(0.1f + Umpire_PowerHeat.chassis_power_buffer * 0.15f);
	} 
}


void Power_off_function(void)//�ϵ籣��
{
			CAN1_SendCommand_chassis(0,0,
														0,0);	
			CAN1_Send_Msg_gimbal(0,0,0);
			fri_on = 0;
			Shoot_Motor = 0;
			friction_wheel_ramp_function();
			Control_data.Vx = 0; 
			Control_data.Vy = 0; 
			Control_data.Chassis_Wz = 0;
			Control_data.Pitch_angle = 0;
			Control_data.Gimbal_Wz = 0;
			Shoot_Motor = 0;//��־λ����
			//Steering_gear_test = 0;
			Shoot_Long = 0;
			close_combatflag = 0;
			Twist_Flag = 0;
			Vision_Flag = 0;
			Gimbal_180_flag = 0;
			SafeHeatflag = 1;
			block_flag = 0;
			Stronghold_flag = 0;
      offline_flag = 0;
      error = 0;
	    Yaw_AnglePid_i = 0;
	    T_yaw = 0;
      P1 = 0;
	    I1 = 0;
	    D1 = 0;
	    angle_output1 = 0;
	    Control_data.Gimbal_Wz = 0;
      E_yaw = imu.yaw;
      Chassismode_flag = 0;
      PWM_Write(PWM2_CH3,0);
      laser_off();			
}
