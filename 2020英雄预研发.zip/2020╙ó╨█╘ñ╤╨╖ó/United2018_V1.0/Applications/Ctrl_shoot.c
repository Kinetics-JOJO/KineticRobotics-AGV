#include "Ctrl_shoot.h"
#include "Ctrl_gimbal.h"
#include "MPU6500.h"
#include "IMU.h"
#include "PID.h"
#include "can1.h"
#include "Configuration.h"
#include "User_Api.h"
#include <math.h>
#include <stdlib.h>
#include "RemoteControl.h"
#include "delay.h"
#include "pwm.h"
#include "Higher_Class.h"
#include "User_Api.h"
#include "FreeRTOS.h"
#include "task.h"
#include "laser.h"
#include "can1.h"
#define Butten_Trig_Pin GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_10)

int32_t trigger_moto_position_ref2;//Ŀ��Ƕ�
int16_t trigger_moto_speed_ref2;//Ŀ���ٶ�
int16_t trigger_moto_current;//���������ֵ

int32_t round_cnt = 0;//���ֵ����תȦ��

int block_flag = 0;//��ת��־
int block_time = 0;//��תʱ��
int blockruntime = 0;//��ת����

int block_flag1 = 0;//��ת��־
int block_time1 = 0;//��תʱ��
int blockruntime1 = 0;//��ת���� 

int time = 0;//��������
int time2 = 0;

int single_flag = 0;
int continue_flag = 0;

int trigger_motor_key_time = 0;
int shoot_ready_flag = 0;




/***************************************************************************/
int Block_42_flag = 0;
int Block_42cnt = 0 ;
int contine_shoot_time1 = 0;  //�����ü��42�����Ƿ�������һ��ʱ��

/**************************************************************************/
//static void Fire_PID_Reset(void)
//{
//	Fire_speed_pid.Kp = 0;
//	Fire_speed_pid.Ki = 0;
//	Fire_speed_pid.Kd = 0;
//	
//	Fire_pid.Kp = 0;
//	Fire_pid.Ki = 0;
//	Fire_pid.Kd = 0;
//}

//static void Fire_PID_Init(void)
//{
//	Fire_speed_pid.Kp = 5;
//	Fire_speed_pid.Ki = 0;
//	Fire_speed_pid.Kd = 0;
//	
//	Fire_pid.Kp = 5;
//	Fire_pid.Ki = 0;
//	Fire_pid.Kd = 0;
//} 

static void Encoder_Data_Handle( M_Data*ptr)//������ת�Ƕȣ�����ֵ����
{
 
  if (ptr->NowAngle - ptr->offset_ecd > 5000)//Ȧ������
  {
    round_cnt--;
  }
  else if (ptr->NowAngle - ptr->offset_ecd < -5000)
  {
    round_cnt++;
  }
  ptr->total_ecd = round_cnt * 8192 + ptr->NowAngle - ptr->offset_ecd;//������ת��ֵ
  ptr->total_angle = ptr->total_ecd * 360 / 8192;//������ת�Ƕ�
}
	

void shoot_ready_control(void)
{
	block_flag = 0;
	block_time = 0;
	blockruntime = 0;
	RC_Ctl.rc.s1_last = RC_Ctl.rc.s1;
	RC_Ctl.mouse.press_l_last = RC_Ctl.mouse.press_l;
if(!Butten_Trig_Pin)////�ж��ӵ�����΢�����ش�
{
	trigger_moto_current = PID_Control(&Fire_speed_pid, 0 ,motor_data[6].ActualSpeed);
	trigger_motor_key_time = 0;
}

else if(Butten_Trig_Pin && trigger_motor_key_time < 1000)//�ж����ӵ�һ��ʱ��
{  
	if(single_flag)//����ģʽת����Լ�����Ƕ�ͣת
	{
		 trigger_moto_speed_ref2 = PID_Control(&Fire_pid, trigger_moto_position_ref2, motor_data[6].total_ecd);
     trigger_moto_current = PID_Control(&Fire_speed_pid, trigger_moto_speed_ref2 ,motor_data[6].ActualSpeed);		
	  if(trigger_motor_key_time > 20)
		trigger_moto_current = PID_Control(&Fire_speed_pid, 0 ,motor_data[6].ActualSpeed);//PID�ٶȻ�
	}
	if(continue_flag)//����ģʽֱ��ͣת
	trigger_moto_current = PID_Control(&Fire_speed_pid, 0 ,motor_data[6].ActualSpeed);//PID�ٶȻ�	
	trigger_motor_key_time++;
}

else if(Butten_Trig_Pin && trigger_motor_key_time == 1000)//΢������һ��ʱ��û���ӵ������벦��
{
	//Fire_PID_Init();

	if(!block_flag1)
	{
	trigger_moto_speed_ref2 = -2000;

	trigger_moto_current = PID_Control(&Fire_speed_pid, trigger_moto_speed_ref2, (motor_data[6].ActualSpeed));
	}
  
	if(!motor_data[6].ActualSpeed)//������ת����
	blockruntime1++;
	else if(motor_data[6].ActualSpeed < 0)
	blockruntime1 = 0;	
	if(blockruntime1 > 300)
	{
	trigger_moto_speed_ref2 = 1000;	
	block_flag1 = 1;
	}
  if(block_flag1)
	{
		block_time1++;
		if(block_time1 > 500)
		{
			block_flag1 = 0;
			block_time1 = 0;
			blockruntime1 = 0;
		}	
	}
 	if(block_flag1)
	trigger_moto_current = PID_Control(&Fire_speed_pid, trigger_moto_speed_ref2, (motor_data[6].ActualSpeed));	
}
}


void shoot_task(void)//ң����ģʽ���Ʋ���
{
	block_flag1 = 0;
  blockruntime1 = 0;
	trigger_motor_key_time = 0;
	//Fire_PID_Init();
	Encoder_Data_Handle( &motor_data[6]);

	if(!block_flag)
	{
	if(RC_Ctl.rc.s1 == RC_SW_DOWN && RC_Ctl.rc.s1_last != RC_SW_DOWN)
	{
	trigger_moto_position_ref2 = motor_data[6].total_ecd + DEGREE_60_TO_ENCODER;//����ģʽ60��
	time = xTaskGetTickCount();
		single_flag = 1;
continue_flag = 0;		
	}
	trigger_moto_speed_ref2 = PID_Control(&Fire_pid, trigger_moto_position_ref2, motor_data[6].total_ecd);

	
  if(RC_Ctl.rc.s1 == RC_SW_DOWN && xTaskGetTickCount() - time > 500)//�󲦸�һֱ��������ģʽ
	{
  trigger_moto_speed_ref2 = -5000;
		single_flag = 0;
continue_flag = 1;		
	}		
	

  trigger_moto_current = PID_Control(&Fire_speed_pid, trigger_moto_speed_ref2, (motor_data[6].ActualSpeed));
	
	RC_Ctl.rc.s1_last = RC_Ctl.rc.s1;
  }
  
	block_bullet_handle();
	
	if((RC_Ctl.rc.s1 != RC_SW_DOWN))
	{
	  trigger_moto_current = 0;
    blockruntime = 0;	
	}
	
}


void shoot_task1()//����ģʽ���Ʋ���
{
	block_flag1 = 0;
  blockruntime1 = 0;
	trigger_motor_key_time = 0;
	//Fire_PID_Init();
	Encoder_Data_Handle( &motor_data[6]);
	if(!block_flag)
	{
	if(RC_Ctl.mouse.press_l && RC_Ctl.mouse.press_l != RC_Ctl.mouse.press_l_last)
	{
	trigger_moto_position_ref2 = motor_data[6].total_ecd + DEGREE_60_TO_ENCODER;//����ģʽ60��
  time = xTaskGetTickCount();
	single_flag = 1;
continue_flag = 0;		
	}

	trigger_moto_speed_ref2 = PID_Control(&Fire_pid, trigger_moto_position_ref2, motor_data[6].total_ecd);//PID�ǶȻ�
	
	if(trigger_moto_position_ref2 - motor_data[6].total_ecd > -1)//��ת�����̶��ǶȻ��������ɿ����ٶȻ�����Ϊ0��ʹ�ò���ͣת
	{
		trigger_moto_speed_ref2 = 0;		
	}
	
  if(RC_Ctl.mouse.press_l && xTaskGetTickCount() - time > 500)//��������������ģʽ
	{
  single_flag = 0;
continue_flag = 1;		
	if(Stronghold_flag)
	{
		trigger_moto_speed_ref2 = -5000;
	}		
	else
	{
  trigger_moto_speed_ref2 = TRIGGER_MOTOR_SPEED*Shootnumber;
	if(trigger_moto_speed_ref2 >= -500)
  trigger_moto_speed_ref2 = -1000;
  }

	}				

	trigger_moto_current = PID_Control(&Fire_speed_pid, trigger_moto_speed_ref2, (motor_data[6].ActualSpeed));//PID�ٶȻ�

	RC_Ctl.mouse.press_l_last = RC_Ctl.mouse.press_l;//��¼�ϴ����������
  }
	
    block_bullet_handle();
	
  if(!RC_Ctl.mouse.press_l)//�������ɿ�
	{
    blockruntime = 0;	
	}		
}


void block_bullet_handle()//�����Զ���ת60��
{
	if((!motor_data[6].ActualSpeed && RC_Ctl.rc.s1 == RC_SW_DOWN && xTaskGetTickCount() - time > 500) | (motor_data[6].ActualSpeed > -20 && RC_Ctl.mouse.press_l && xTaskGetTickCount() - time > 500))//����ģʽ������ת
	blockruntime++;
	else if((motor_data[6].ActualSpeed < 0 && RC_Ctl.rc.s1 == RC_SW_DOWN)| (motor_data[6].ActualSpeed < 0 && RC_Ctl.mouse.press_l))
	blockruntime = 0;	
	
	if(!motor_data[6].ActualSpeed && blockruntime > 300)
	{
	trigger_moto_speed_ref2 = 5000;
	block_flag = 1;
	}
	
	if(block_flag)
	{
	block_time++;
  if(block_time > 500)
	{
		blockruntime = 0;
    block_flag  = 0;
    block_time = 0; 		
	}	
  }
	if(block_flag)
   trigger_moto_current = PID_Control(&Fire_speed_pid, trigger_moto_speed_ref2, (motor_data[6].ActualSpeed));
}


/*****************************42mm�������****************************************************************************/


