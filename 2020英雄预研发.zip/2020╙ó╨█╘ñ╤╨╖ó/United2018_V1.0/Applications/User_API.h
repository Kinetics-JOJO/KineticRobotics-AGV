#ifndef __USERAPI_H
#define __USERAPI_H
#include "sys.h"


typedef struct
{
	float Vx;			//ǰ���ٶ�
	float Vy;			//�����ٶ�
	float Chassis_Wz;			//��ת�ٶ�
	float Gimbal_Wz;
	float Gimbal_Wzlast;
	float Pitch_angle;	//pitch��Ƕ�
	
}ControlDATA_TypeDef;

//�������
typedef struct
{
	u16 Frequency;	//��Ƶ
	float Speed;		//����
	
}ShootProject_TypeDef;

extern ControlDATA_TypeDef Control_data;//��������
extern u8 Twist_Flag;				//Ť��
extern u8 Vision_Flag;			//�Ӿ�����
extern u8 Shoot_Flag;				//���
extern u8 Shoot_Motor;			//Ħ����
extern u8 Gimbal_180_flag;
extern u8 close_combatflag;
extern u8 Steering_gear_test;
extern u8 Shoot_Long;
extern int SafeHeatflag;
extern u8 Stronghold_flag;
extern int Chassismode_flag;
extern int Gimbalmode_flag;
extern int Shootnumber;
extern int Shootspeed; 
extern int Shootnumber_fired;


void User_Api(void);
void computer_ctrl(void);
void computer_handle(void);
void FRT_computer_ctrl(void *pvParameters);
static void ShooterHeat_Ctrl(void);
void chassis_control_acquisition(void);
void gimbal_control_acquisition(void);
#endif


